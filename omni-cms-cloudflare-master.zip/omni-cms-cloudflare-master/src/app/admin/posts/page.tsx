'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Search, ChevronLeft, ChevronRight, Edit, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { useOrganization } from '@/lib/context/organization-context';
import { useApiClient } from '@/lib/hooks/use-api-client';
import { useErrorHandler } from '@/lib/hooks/use-error-handler';
import { useSchema } from '@/lib/hooks/use-schema';
import { Spinner } from '@/components/ui/spinner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Post {
  id: string;
  title: string;
  slug: string;
  status: 'draft' | 'published' | 'archived';
  createdAt: string;
  updatedAt: string;
  author?: {
    id: string;
    name: string;
    email: string;
  };
  postType?: {
    id: string;
    name: string;
    slug: string;
  };
}

interface PaginatedResponse {
  success: true;
  data: Post[];
  meta: {
    page: number;
    perPage: number;
    total: number;
    totalPages: number;
  };
}

export default function PostsPage() {
  const { organization } = useOrganization();
  const api = useApiClient();
  const { error, handleError, clearError, withErrorHandling } = useErrorHandler();
  const { schema: postsSchema } = useSchema('posts');
  
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [perPage] = useState(20);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [postTypeFilter, setPostTypeFilter] = useState<string>('all');
  const [debouncedSearch, setDebouncedSearch] = useState('');

  // Get status enum values from schema
  const statusEnum = postsSchema?.enums?.status?.values || ['draft', 'published', 'archived'];
  const statusProperty = postsSchema?.properties?.find(p => p.name === 'status');
  const statusOptions = statusProperty?.options || [
    { value: 'draft', label: 'Draft' },
    { value: 'published', label: 'Published' },
    { value: 'archived', label: 'Archived' },
  ];

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1); // Reset to first page on search
    }, 500);

    return () => clearTimeout(timer);
  }, [search]);

  // Fetch posts
  useEffect(() => {
    if (!organization) {
      setLoading(false);
      return;
    }

    const fetchPosts = withErrorHandling(async () => {
      setLoading(true);
      clearError();

      const params: Record<string, string> = {
        page: page.toString(),
        per_page: perPage.toString(),
      };

      if (debouncedSearch) {
        params.search = debouncedSearch;
      }

      if (statusFilter !== 'all') {
        params.status = statusFilter;
      }

      if (postTypeFilter !== 'all') {
        params.post_type = postTypeFilter;
      }

      const response = (await api.getPosts(params)) as PaginatedResponse;
      
      if (response.success) {
        setPosts(response.data);
        setTotal(response.meta.total);
      } else {
        handleError('Failed to load posts', { title: 'Failed to Load Posts' });
      }
      setLoading(false);
    }, { title: 'Failed to Load Posts' });

    fetchPosts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organization, page, debouncedSearch, statusFilter, postTypeFilter, api, perPage]);

  if (!organization) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">
              Please select an organization to view posts.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalPages = Math.ceil(total / perPage);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Posts</h1>
          <p className="text-muted-foreground">
            Manage your content posts
          </p>
        </div>
        <Link href="/admin/posts/new">
          <Button aria-label="Create new post">
            <Plus className="mr-2 h-4 w-4" aria-hidden="true" />
            <span className="hidden sm:inline">New Post</span>
            <span className="sm:hidden">New</span>
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search posts by title..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                aria-label="Search posts"
                type="search"
              />
            </div>

            {/* Filters */}
            <div className="flex gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    Status: {statusFilter === 'all' ? 'All' : statusFilter}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setStatusFilter('all')}>
                    All
                  </DropdownMenuItem>
                  {statusOptions.map((option) => (
                    <DropdownMenuItem
                      key={option.value}
                      onClick={() => setStatusFilter(option.value)}
                    >
                      {option.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {postTypeFilter !== 'all' && (
                <Button
                  variant="outline"
                  onClick={() => setPostTypeFilter('all')}
                >
                  Clear Type Filter
                </Button>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {loading && (
            <div className="text-center py-8 flex items-center justify-center gap-2">
              <Spinner size="sm" />
              <p className="text-sm text-muted-foreground">Loading posts...</p>
            </div>
          )}

          {error && (
            <div className="text-center py-8">
              <p className="text-sm text-destructive">{error}</p>
            </div>
          )}

          {!loading && !error && posts.length === 0 && (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">
                No posts found. Create your first post to get started.
              </p>
            </div>
          )}

          {!loading && !error && posts.length > 0 && (
            <>
              {/* Desktop Table View */}
              <div className="hidden md:block rounded-md border overflow-x-auto">
                <table className="w-full" role="table" aria-label="Posts list">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="h-10 px-4 text-left align-middle font-medium text-sm" scope="col">
                        Title
                      </th>
                      <th className="h-10 px-4 text-left align-middle font-medium text-sm" scope="col">
                        Type
                      </th>
                      <th className="h-10 px-4 text-left align-middle font-medium text-sm" scope="col">
                        Status
                      </th>
                      <th className="h-10 px-4 text-left align-middle font-medium text-sm" scope="col">
                        Author
                      </th>
                      <th className="h-10 px-4 text-left align-middle font-medium text-sm" scope="col">
                        Updated
                      </th>
                      <th className="h-10 px-4 text-right align-middle font-medium text-sm" scope="col">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {posts.map((post) => (
                      <tr key={post.id} className="border-b hover:bg-muted/50">
                        <td className="p-4 align-middle">
                          <div>
                            <div className="font-medium">{post.title}</div>
                            <div className="text-xs text-muted-foreground">
                              {post.slug}
                            </div>
                          </div>
                        </td>
                        <td className="p-4 align-middle text-sm">
                          {post.postType?.name || '—'}
                        </td>
                        <td className="p-4 align-middle">
                          <span
                            className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                              post.status === 'published'
                                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                                : post.status === 'draft'
                                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                                : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'
                            }`}
                            aria-label={`Status: ${post.status}`}
                          >
                            {post.status}
                          </span>
                        </td>
                        <td className="p-4 align-middle text-sm">
                          {post.author?.name || '—'}
                        </td>
                        <td className="p-4 align-middle text-sm text-muted-foreground">
                          {post.updatedAt
                            ? new Date(post.updatedAt).toLocaleDateString()
                            : '—'}
                        </td>
                        <td className="p-4 align-middle text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Link href={`/admin/posts/${post.id}`} aria-label={`Edit post: ${post.title}`}>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4" aria-hidden="true" />
                              </Button>
                            </Link>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive hover:text-destructive"
                              aria-label={`Delete post: ${post.title}`}
                              onClick={async () => {
                                if (
                                  confirm(
                                    `Are you sure you want to delete "${post.title}"?`
                                  )
                                ) {
                                  await withErrorHandling(async () => {
                                    await api.deletePost(post.id);
                                    // Refresh posts by triggering a refetch
                                    setPage(1);
                                  }, { title: 'Failed to Delete Post' })();
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4" aria-hidden="true" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card View */}
              <div className="md:hidden space-y-4">
                {posts.map((post) => (
                  <Card key={post.id}>
                    <CardContent className="pt-6">
                      <div className="space-y-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-medium">{post.title}</h3>
                            <p className="text-xs text-muted-foreground mt-1">{post.slug}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Link href={`/admin/posts/${post.id}`} aria-label={`Edit post: ${post.title}`}>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4" aria-hidden="true" />
                              </Button>
                            </Link>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive hover:text-destructive"
                              aria-label={`Delete post: ${post.title}`}
                              onClick={async () => {
                                if (
                                  confirm(
                                    `Are you sure you want to delete "${post.title}"?`
                                  )
                                ) {
                                  await withErrorHandling(async () => {
                                    await api.deletePost(post.id);
                                    setPage(1);
                                  }, { title: 'Failed to Delete Post' })();
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4" aria-hidden="true" />
                            </Button>
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Type: </span>
                            <span>{post.postType?.name || '—'}</span>
                          </div>
                          <div>
                            <span
                              className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                                post.status === 'published'
                                  ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                                  : post.status === 'draft'
                                  ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                                  : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'
                              }`}
                              aria-label={`Status: ${post.status}`}
                            >
                              {post.status}
                            </span>
                          </div>
                          {post.author && (
                            <div>
                              <span className="text-muted-foreground">Author: </span>
                              <span>{post.author.name}</span>
                            </div>
                          )}
                          {post.updatedAt && (
                            <div>
                              <span className="text-muted-foreground">Updated: </span>
                              <span>{new Date(post.updatedAt).toLocaleDateString()}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Showing {(page - 1) * perPage + 1} to{' '}
                    {Math.min(page * perPage, total)} of {total} posts
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage((p) => Math.max(1, p - 1))}
                      disabled={page === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                      Previous
                    </Button>
                    <div className="text-sm">
                      Page {page} of {totalPages}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                      disabled={page === totalPages}
                    >
                      Next
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
